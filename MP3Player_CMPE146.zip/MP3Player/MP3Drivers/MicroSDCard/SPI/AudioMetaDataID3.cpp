/*
 * AudioMetaDataID3.cpp
 *
 *  Created on: May 12, 2018
 *      Author: james
 */

#include <MP3Player/MP3Drivers/MicroSDCard/SPI/AudioMetaDataID3.h>

AudioMetaDataID3::AudioMetaDataID3()
{
    // TODO Auto-generated constructor stub

}

AudioMetaDataID3::~AudioMetaDataID3()
{
    // TODO Auto-generated destructor stub
}

